/**
 * Contains stories for Podam constructors handling.
 * Created by tedonema on 14/06/2015.
 */
package uk.co.jemos.podam.test.unit.features.constructors;