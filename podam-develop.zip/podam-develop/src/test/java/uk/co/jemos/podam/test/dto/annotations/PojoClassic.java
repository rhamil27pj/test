package uk.co.jemos.podam.test.dto.annotations;

/**
 * Created by tedonema on 07/06/2015.
 */
public class PojoClassic {

    private String att;

    public String getAtt() {
        return att;
    }

    public void setAtt(String att) {
        this.att = att;
    }
}
