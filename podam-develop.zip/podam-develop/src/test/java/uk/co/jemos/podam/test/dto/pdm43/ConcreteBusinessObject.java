/**
 * 
 */
package uk.co.jemos.podam.test.dto.pdm43;

/**
 * @author mtedone
 * 
 */
public class ConcreteBusinessObject extends BusinessObjectWithErrors<Long>
		implements Cloneable {

}
