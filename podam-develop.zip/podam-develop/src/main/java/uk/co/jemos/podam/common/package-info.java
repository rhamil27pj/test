/**
 * This package contains PODAM common APIs
 */
package uk.co.jemos.podam.common;

